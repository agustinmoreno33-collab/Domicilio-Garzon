# Domicilio Garzón — proyecto Android

Proyecto Android listo para abrir en Android Studio y generar el APK.

## Generar APK
1. Abra esta carpeta en Android Studio.
2. Espere a que finalice la sincronización de Gradle.
3. Seleccione **Build > Build APK(s)**.
4. El APK de depuración quedará normalmente en:
   `app/build/outputs/apk/debug/app-debug.apk`

## Funciones incluidas
- Clientes guardados
- Registro de domicilios
- Teléfono y dirección
- Dinero inicial del día
- Pagos en efectivo y transferencia
- Gastos
- Cierre de caja
- Resumen diario
- Almacenamiento local en el dispositivo

El archivo `app/src/main/assets/index.html` contiene la aplicación de Domicilio Garzón.
